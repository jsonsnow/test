//
//  NSString+CLStringTool.h
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/22.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CLStringTool)
+(instancetype)convertHanZiToPingYing:(NSString *)string;

@end
