//
//  CLCurrentPlayControl.m
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/18.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import "CLCurrentPlayControl.h"
#import "CLOnlieMusicControl.h"

@interface CLCurrentPlayControl ()

@end

@implementation CLCurrentPlayControl

//-(instancetype)initWithCoder:(NSCoder *)aDecoder{
//    
//    
//    
//    if (self=[super initWithCoder:aDecoder]) {
//        
//        CLOnlieMusicControl *onlie=[[CLOnlieMusicControl alloc] initWithNibName:@"CLOnlieMusicControl" bundle:nil];
//        self = [[CLCurrentPlayControl alloc] initWithRootViewController:onlie];
//    }
//    
//    
//    
//    return self;
//    
//}
//-(instancetype)init{
//    
//    
//    if (self=[super init]) {
//        
//        
//        self = [[CLCurrentPlayControl alloc] initWithRootViewController:onlie];
//    }
//    
//    
//    
//    return self;
//
//    
//    
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.


//    CLOnlieMusicControl *onlie=[[CLOnlieMusicControl alloc] init];
//    CGRect frame=[[UIScreen mainScreen] bounds];
//    onlie.view.bounds=CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.height-100);
//    [self addChildViewController:onlie];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
