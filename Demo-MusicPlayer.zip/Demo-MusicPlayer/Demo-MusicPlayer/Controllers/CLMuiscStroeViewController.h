//
//  CLMuiscStroeViewController.h
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/17.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLMuiscStroeViewController : UIViewController

@end
