//
//  AppDelegate.h
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/7.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;




@end

