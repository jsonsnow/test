//
//  CLMusicGroupTool.h
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/22.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLMusicGroupTool : NSObject

+(instancetype)managerGroup;

-(NSArray *)getALLMusicGroup;

@end
