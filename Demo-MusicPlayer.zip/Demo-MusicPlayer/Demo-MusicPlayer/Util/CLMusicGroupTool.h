//
//  CLMusicGroupTool.h
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/22.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CLMusic;

@interface CLMusicGroupTool : NSObject

+(instancetype)managerGroup;
-(NSArray *)getALLMusicGroup;

/// 增加音乐的时候 为音乐组也增加
-(void)addMusicFromOnceGroup:(CLMusicOnBaiDuIcon *)music;
///删除音乐的时候相应删除组中的音乐
-(void)deleteMusicFromOnceGroup:(CLMusicOnBaiDuIcon *)music;

@end
